import { BrowserRouter, Routes, Route } from "react-router-dom";
import NavBar from './components/NavBar';
import HomePage from './pages/HomePage';
import SearchResultsPage from "./pages/SearchResultsPage";
import BusinessPage from './pages/BusinessPage';
import CategoryPage from './pages/CategoryPage';
import UserPage from "./pages/UserPage";

export default function App() {
  return (
    <BrowserRouter>
      <NavBar />
      <Routes>
        <Route path="/yelp" element={<HomePage />} />
        <Route path="/yelp/search" element={<SearchResultsPage />} />
        <Route path="/yelp/business/:businessId" element={<BusinessPage />} />
        <Route path="/yelp/category" element={<CategoryPage />} />
        <Route path="/yelp/user/:userId" element={<UserPage />} />
      </Routes>
    </BrowserRouter>
  );
}