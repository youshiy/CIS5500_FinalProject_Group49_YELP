import { Container, Divider, Link } from '@mui/material';

import ScrollingBillboard from '../components/ScrollingBillboard';
import ReviewCards from '../components/ReviewCards';
const config = require('../config.json');

export default function HomePage() {
  return (
    <div>
      <ScrollingBillboard/>
      <Divider style={{ margin: '50px 20px' }} />
      <ReviewCards/>
      <Divider style={{ margin: '50px 20px' }} />
      <footer className="yelp-footer">
        <div className="footer-content">
          <div className="footer-logo">
            <img src="/images/yelp_title.jpg" style={{width:'70px'}}/>
          </div>
          <div className="footer-info">
            <p> Copyright &copy; 2004–2023 Yelp Inc</p>
            <p>
              This website is not affiliated with or endorsed by Yelp. Yelp logo and related marks are registered
              trademarks of Yelp, Inc.
            </p>
          </div>
        </div>
      
    </footer>
    </div>
  );
};