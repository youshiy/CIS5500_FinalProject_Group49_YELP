import React, { useEffect, useState } from 'react';
import { Box, Container, Avatar, Typography, Button } from '@mui/material';
import { useParams } from 'react-router-dom';

import LightbulbOutlinedIcon from '@mui/icons-material/LightbulbOutlined';
import FavoriteBorderOutlinedIcon from '@mui/icons-material/FavoriteBorderOutlined';
import HealthAndSafetyOutlinedIcon from '@mui/icons-material/HealthAndSafetyOutlined';

const config = require('../config.json');

export default function UsersPage() {
    const { userId } = useParams();
    const [user, setUser] = useState({
        name: '',
        location: 'San Antonio, TX',
        elite: [],
        average_stars: undefined,
        useful: 0,
        funny: 0,
        cool: 0,
    });

    useEffect(() => {
        fetch(`http://${config.server_host}:${config.server_port}/yelp/user_details/${userId}`)
            .then(response => response.json())
            .then(data => {
                if (data.elite) {
                    data.elite = data.elite.split(',').map(year => year.trim()).sort((a, b) => b - a);
                }
                setUser(data);
            })
            .catch(error => console.error('Error fetching user details:', error));
    }, [userId]);

    return (
        <Container sx={{ display: "flex", flexDirection: "row", marginTop: 2 }}>
            <Box sx={{ width: "300px", minHeight: "500px", display: "flex", flexDirection: "column", border: "1px solid gray", position: "relative" }}>
                <Box sx={{ background: "red", height: 50, width: "100%", position: "absolute", top: 0 }}></Box>
                <Avatar alt="User Avatar" sx={{ width: 80, height: 80, margin: "auto", position: "absolute", top: 30, left: "calc(50% - 40px)" }} src="/images/user.png" />
                <Box sx={{ marginTop: "120px", textAlign: "center", padding: "20px" }}>
                    <Typography variant='h5'>{user.name}</Typography>
                    <Typography sx={{ color: "gray" }}>{user.location}</Typography>
                    {user.elite && user.elite.length > 0 && (
                        <Box sx={{ margin: "10px 0", backgroundColor: "red", color: "white", padding: "5px" }}>
                            {user.elite.map((year, index) => (
                                <Typography key={index} variant="body2" sx={{ display: 'block' }}>
                                    ELITE {year}
                                </Typography>
                            ))}
                        </Box>
                    )}
                </Box>
                <Box sx={{ position: "absolute", bottom: 20, left: 0, right: 0, textAlign: "center" }}>
                    <Button variant="contained" sx={{ marginBottom: "10px" }}>
                        Profile overview
                    </Button>
                </Box>
            </Box>
            <Box sx={{ flex: 1, padding: "10px" }}>
                <Typography variant='h5' sx={{ marginBottom: "20px" }}>Impact</Typography>
                <Box sx={{
                    display: "flex",
                    flexDirection: "row",
                    width: "100%",
                    justifyContent: "space-between"
                }}>
                    <Box sx={{
                        display: "flex",
                        flexDirection: "column",
                        width: "45%",
                        border: "solid 1px lightgray",
                        borderRadius: "10px",
                        padding: "10px"
                    }}>
                        <Typography variant='h6'>Review reactions</Typography>
                        <Box sx={{
                            display: "flex",
                            flexDirection: "row",
                            justifyContent: "space-between",
                        }}>
                            <Box sx={{
                                display: "flex",
                                flexDirection: "column",
                                justifyContent: "center",
                                alignItems: "center"
                            }}>
                                <LightbulbOutlinedIcon color='gray'/>
                                <Typography sx={{ fontSize: "12px", color: "gray" }}>Useful</Typography>
                                <Typography sx={{ fontSize: "12px", color: "gray" }}>{user.useful}</Typography>
                            </Box>
                            <Box sx={{
                                display: "flex",
                                flexDirection: "column",
                                justifyContent: "center",
                                alignItems: "center"
                            }}>
                                <HealthAndSafetyOutlinedIcon color='gray'/>
                                <Typography sx={{ fontSize: "12px", color: "gray" }}>Funny</Typography>
                                <Typography sx={{ fontSize: "12px", color: "gray" }}>{user.funny}</Typography>
                            </Box>
                            <Box sx={{
                                display: "flex",
                                flexDirection: "column",
                                justifyContent: "center",
                                alignItems: "center"
                            }}>
                                <FavoriteBorderOutlinedIcon color='gray'/>
                                <Typography sx={{ fontSize: "12px", color: "gray" }}>Cool</Typography>
                                <Typography sx={{ fontSize: "12px", color: "gray" }}>{user.cool}</Typography>
                            </Box>
                        </Box>
                    </Box>
                    <Box sx={{
                        display: "flex",
                        flexDirection: "column",
                        width: "45%",
                        border: "solid 1px lightgray",
                        borderRadius: "10px",
                        padding: "10px"
                    }}>
                        <Typography variant='h6'>Stats</Typography>
                        <Typography sx={{ fontSize: "12px", color: "gray" }}>Average Stars</Typography>
                        <Typography sx={{ fontSize: "12px" }}>{user.average_stars}</Typography>
                        <Typography sx={{ fontSize: "12px", color: "gray" }}>Yelp Elite</Typography>
                        <Typography sx={{ fontSize: "12px" }}>
                            {user.elite && user.elite.length > 0 ? `${user.elite.join(', ')} Years` : 'None'}
                        </Typography>
                    </Box>
                </Box>
            </Box>
        </Container>
    );
}
