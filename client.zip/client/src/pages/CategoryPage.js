import React, { useEffect, useState } from 'react';
import { Container, Box, Card, CardMedia, CardContent, Typography, Divider, Rating, Button, Slider } from '@mui/material';
import axios from 'axios';
import { NavLink, useSearchParams } from 'react-router-dom';

const config = require('../config.json');

function CategoryPage() {
  const searchParams = useSearchParams("state");

  const [bussinesses, setBusinesses] = useState([]);
  const [categories, setCategories] = useState([]);
  const [locations, setLocations] = useState([]);

  const [categoryPos, setCategoryPos] = useState(3);
  const [locationPos, setLocationPos] = useState(3);
  const [statePos, setStatePos] = useState(3);
  const [baseCategory, setBaseCategory] = useState('Restaurant');

  const [filters, setFilters] = useState({
    states: [],
    cities: [],
    categories: [],
    keyword: '',
    rating: 5, 
    review_count: 0
  });
  const [orders, setOrders] = useState('Reviewed');
  const [loading, setLoading] = useState(false);

  const allStates = ["AZ","BW","BY","CHE","CMA","EDH","ELN","ESX","FIF","GA","HLD",
  "IL","KY","MLN","NC","NI","NV","NY","NYK","OH","ON","PA","QC","SC","SCB","ST","WI","WLN","XGL"];
  const images = [
    { src: "/photos/p1.jpg"},
    { src: "/photos/p2.jpg"},
    { src: "/photos/p3.jpg"},
    { src: "/photos/p4.jpg"},
    { src: "/photos/p5.jpg"},
    { src: "/photos/p6.jpg"},
    { src: "/photos/p7.jpg"},
    { src: "/photos/p8.jpg"},
    { src: "/photos/p9.jpg"},
    { src: "/photos/p10.jpg"},
    { src: "/photos/p11.jpg"},
    { src: "/photos/p12.jpg"},
    { src: "/photos/p13.jpg"},
    { src: "/photos/p14.jpg"},
    { src: "/photos/p15.jpg"},
    { src: "/photos/p16.jpg"},
    { src: "/photos/p17.jpg"},
    { src: "/photos/p18.jpg"},
    { src: "/photos/p19.jpg"},
    { src: "/photos/p20.jpg"},
  ];

 
  useEffect(() => {
    setLoading(true);
    axios.get(`http://${config.server_host}:${config.server_port}/yelp/categories`)
      .then(response => {
        setCategories(response.data.data) // categories
      })
      .catch(error => console.error('Error fetching business details:', error));
    
    axios.get(`http://${config.server_host}:${config.server_port}/yelp/locations`)
      .then(response => {
        setLocations(response.data.data) // city
      })
      .catch(error => console.error('Error fetching business details:', error));
    
    const keyword = searchParams[0].getAll("keyword")[0] || '';
    const baseC = searchParams[0].getAll("category")[0];
    if (baseC && baseC !== '' && baseC !== baseCategory) {
      setBaseCategory(baseC);
    }
    const state = searchParams[0].getAll("state")[0];
    if (state && state !== '') {
      if (!filters.states.includes(state)) {
        filters.states.push(state);
      }
    }
    axios.get(`http://${config.server_host}:${config.server_port}/yelp/recommendations?category=${filters.categories.toString()}&keywords=${keyword}&state=${filters.states.toString()}&city=${filters.cities.toString()}&order=${orders}&rating=${filters.rating}&baseCategory=${baseCategory}&review_count=${filters.review_count}`)
        .then(response => {
          if (Array.isArray(response.data)) {
            setBusinesses(response.data)
          } else {
            setBusinesses([])
          }
          setLoading(false);
        })
        .catch(error => console.error('Error fetching business details:', error));
  }, [filters, orders, baseCategory])

  function showAllCategories() {
    if (categoryPos === 3) {
      setCategoryPos(categories.length);
    } else {
      setCategoryPos(3);
    }
  }

  function showAllCity() {
    if (locationPos === 3) {
      setLocationPos(locations.length);
    } else {
      setLocationPos(3);
    }
  }

  function showAllState() {
    if (statePos === 3) {
      setStatePos(allStates.length);
    } else {
      setStatePos(3);
    }
  }

  return (
    <Container sx={{
      display: 'flex',
      flexDirection: 'row'
    }}>
      <Box sx={{
        display: 'flex',
        flexDirection: 'column',
        padding: "10px",
        flexGrow: 1
      }}>
        <Box sx={{ marginBottom: "10px" }}>
          {/* Top Category */}
          <Box sx={{ padding: "10px", display: "flex", flexDirection: "row", alignItems: "center" }}>
            <Typography component="div" sx={{ marginRight: "10px" }}>Business type: </Typography>
            <Button variant={baseCategory === 'Restaurant' ? 'contained' : 'text'} onClick={() => {
              setBaseCategory('Restaurant')
            }}>Restaurant</Button>
            <Button variant={baseCategory === 'Home Service' ? 'contained' : 'text'} onClick={() => {
              setBaseCategory('Home Service')
            }}>Home Service</Button>
            <Button variant={baseCategory === 'Auto Service' ? 'contained' : 'text'} onClick={() => {
              setBaseCategory('Auto Service')
            }}>Auto Service</Button>
            <Button variant={baseCategory === 'Others' ? 'contained' : 'text'} onClick={() => {
              setBaseCategory('Others')
            }}>Others</Button>
          </Box>
          <Box sx={{ padding: "10px", display: "flex", flexDirection: "row", alignItems: "center" }}>
            <Typography component="div" sx={{ marginRight: "10px" }}>Sort By: </Typography>
            <Button variant={orders === 'Reviewed' ? 'contained' : 'text'} onClick={() => {
              setOrders('Reviewed')
            }}>Most Reviewed</Button>
            <Button variant={orders === 'Rated' ? 'contained' : 'text'} onClick={() => {
              setOrders('Rated')
            }}>Highest Rated</Button>
            <Button variant={orders === 'Name' ? 'contained' : 'text'} onClick={() => {
              setOrders('Name')
            }}>Name</Button>
          </Box>
          <Divider />
        </Box>
        <Box>
          {/* Business Lists */}
          {
            !loading ? bussinesses.map((business, pos) => {
              return (
                <NavLink to={`/yelp/business/${business.business_id}`}>
                  <Card sx={{ marginBottom: "10px" }}>
                    <CardMedia
                      sx={{ height: 140 }}
                      image={`/photos/p` + (business.review_count%49) + `.jpg`}
                      title="green iguana"
                    />
                    <CardContent>
                      <Typography gutterBottom variant="h5" component="div" sx={{ display: "flex", alignItems: "center" }}>
                        { business.name }
                        <Rating
                            name="simple-controlled"
                            disabled={true}
                            value={business.stars}
                            sx={{ marginRight: "10px", marginLeft: "10px" }}
                        />
                        <div >
                          {/* Render categories */}
                          {business.categories.split(',').map((category, index) => (
                          <span key={index} >
                            <Button size="small" variant="contained" sx={{ marginRight: "10px" }}>{category}</Button>
                            </span>
                            ))}
                            </div>
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                      {business.state}{"   |   "}{business.city}{"   |   "}Review Count: {business.review_count}
                      </Typography>
                    </CardContent>
                  </Card>
                </NavLink>
              )
            }) : "loading"
          }
        </Box>
      </Box>
      <Box sx={{ padding: "10px", minWidth: "200px" }}>
        {/* side filter menus */}
        <Typography sx={{ marginBottom: "20px" }}>Filters</Typography>
        <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "start", alignItems: "start" }}>
          <Typography variant='h6'>Rating range</Typography>
          <Slider
            value={filters.rating}
            valueLabelDisplay="auto"
            step={0.5}
            marks
            min={0}
            max={5}
            onChange={(_, value) => {
              setFilters({
                ...filters,
                rating: value
              })
            }}
          />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "start", alignItems: "start" }}>
          <Typography variant='h6'>Minimum reviews</Typography>
          <Slider
            value={filters.review_count}
            step={1}
            min={0}
            max={500}
            onChange={(_, value) => {
              setFilters({
                ...filters,
                review_count: value
              })
            }}
          />
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "start", alignItems: "start" }}>
          <Typography variant='h6'>Category</Typography>
          <Button onClick={showAllCategories}>{ categoryPos === 3 ? 'See All' : "Hide All"}</Button>
          {
            categories && categories.filter((_, pos) => pos < categoryPos).map(c => {
              return <Button key={c.cate} variant={filters.categories.includes(c.categories) ?  'contained' : 'text' } onClick={() => {
                if (filters.categories.includes(c.categories)) {
                  const pos = filters.categories.findIndex(el => el === c.categories);
                  if (pos > -1) {
                    filters.categories.splice(pos, 1);
                    setFilters({
                      ...filters
                    })
                  }
                } else {
                  setFilters({
                    ...filters,
                    categories: [
                      ...filters.categories,
                      c.categories
                    ]
                  })
                }
              }}>{c.categories}</Button>
            })
          }
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "start", alignItems: "start" }}>
          <Typography variant='h6'>State</Typography>
          <Button onClick={showAllState}>{ statePos === 3 ? 'See All' : "Hide All"}</Button>
          {
            allStates.filter((_, pos) => pos < statePos).map(c => {
              return <Button key={c} variant={filters.states.includes(c) ?  'contained' : 'text' } onClick={() => {
                if (filters.states.includes(c)) {
                  const pos = filters.states.findIndex(el => el === c);
                  if (pos > -1) {
                    filters.states.splice(pos, 1);
                    setFilters({
                      ...filters
                    })
                  }
                } else {
                  setFilters({
                    ...filters,
                    states: [
                      ...filters.states,
                      c
                    ]
                  })
                }
              }}>{c}</Button>
            })
          }
        </Box>
        <Box sx={{ display: "flex", flexDirection: "column", justifyContent: "start", alignItems: "start" }}>
          <Typography variant='h6'>City</Typography>
          <Button onClick={showAllCity}>{ locationPos === 3 ? 'See All' : "Hide All"}</Button>
          {
            locations && locations.filter((_, pos) => pos < locationPos).map(c => {
              return <Button key={c.city} variant={filters.cities.includes(c.city) ?  'contained' : 'text' } onClick={() => {
                if (filters.cities.includes(c.city)) {
                  const pos = filters.cities.findIndex(el => el === c.city);
                  if (pos > -1) {
                    filters.cities.splice(pos, 1);
                    setFilters({
                      ...filters
                    })
                  }
                } else {
                  setFilters({
                    ...filters,
                    cities: [
                      ...filters.cities,
                      c.city
                    ]
                  })
                }
              }}>{c.city}</Button>
            })
          }
        </Box>
      </Box>
    </Container>
  )
}

export default CategoryPage;