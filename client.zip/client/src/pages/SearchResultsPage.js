import { Container, Link } from '@mui/material';
import React from 'react';
import { useEffect, useState } from 'react';
import { useLocation } from 'react-router-dom';
import './SearchResultsPage.css';
const config = require('../config.json');

const SearchResults = () => {
  const location = useLocation();
  const searchParams = new URLSearchParams(location.search);

  const category = searchParams.get('category');
  const keyword = searchParams.get('keyword');
  const city = searchParams.get('city');
  const state = searchParams.get('state');

  const [business, setBusiness] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);

    fetch(`http://${config.server_host}:${config.server_port}/yelp/search?category=${category}` +
      `&keywords=${keyword}&city=${city}&state=${state}`
    )
      .then(res => res.json())
      .then(resJson => {
        setBusiness(resJson);
        setLoading(false);
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        setLoading(false);
      });
  }, [category, keyword, city, state]);

  const renderStars = (rating) => {
    const stars = [];
  
    for (let i = 1; i < 6; i++) {
      if (i < rating && (i+1)> rating) {
        stars.push(<span key={i} className="star half-filled">&#9733;</span>);
      } else if (i < rating) {
        stars.push(<span key={i} className="star filled">&#9733;</span>);
      } else {
        stars.push(<span key={i} className="star">&#9733;</span>);
      }
    }
  
    return stars;
  };

  return (
    <Container>
      <h1>Best {keyword} {category} nearby</h1>

      <div>
        {loading && <p>Loading...</p>}

        {!loading && Object.keys(business).length === 0 && <p>No businesses found.</p>}

        {!loading && Object.keys(business).length > 0 && business.map(item => (
          <div key={item.business_id} className="business-block">
            <img src={`/photos/p` + (item.review_count%50) + `.jpg`} className="business-image" />
            <div className="business-details">
              <a href={`/yelp/business/${item.business_id}`} style={{ textDecoration: 'none', color: 'black' }}>
                <h2>{item.name}</h2>
              </a>
              <div className="categories">
                {/* Render categories */}
                {item.categories.split(',').map((category, index) => (
                  <span key={index} className="category">
                    {category.trim()}
                  </span>
                ))}
              </div>
              <p className="business-text">
                Address: {item.address}, {item.city}, {item.state}
              </p>
              <p className="business-text">
                Rating: {renderStars(item.stars)}
              </p>
            </div>
          </div>
        ))}
      </div>
    </Container>
  );
};

export default SearchResults;