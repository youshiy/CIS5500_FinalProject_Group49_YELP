import React, { useState, useEffect } from 'react';
import { Container, Box, Card, CardMedia, CardContent, Typography, Divider, ButtonGroup, Button, Rating } from '@mui/material';
import axios from 'axios';
import { useParams } from 'react-router-dom';
import { NavLink } from 'react-router-dom';
import Plot from 'react-plotly.js';

const config = require('../config.json');

function BusinessPage() {
    const { businessId } = useParams();
    const [businessDetails, setBusinessDetails] = useState({});
    const [recentTips, setRecentTips] = useState([]);
    const [loading, setLoading] = useState(true);
    const [data, setData] = useState([])
    useEffect(() => {
        // Fetch business details
        axios.get(`http://${config.server_host}:${config.server_port}/yelp/business_details/${businessId}`)
            .then(response => {
                console.log(response.data);
                setBusinessDetails(response.data);
            })
            .catch(error => console.error('Error fetching business details:', error));
        // Fetch daily checkins

        // Fetch recent tips
        axios.get(`http://${config.server_host}:${config.server_port}/yelp/business_tips/${businessId}`)
            .then(response => {
                setRecentTips(response.data);
            })
            .catch(error => console.error('Error fetching recent tips:', error))
            .finally(() => setLoading(false));
        
        // get checkin
        axios.get(`http://${config.server_host}:${config.server_port}/yelp/business_checkins/${businessId}`)
            .then(response => {
                console.log(response.data)
                setData(response.data);
            })
            .catch(error => console.error('Error fetching recent tips:', error))
    }, [businessId]);

    console.log("tips", recentTips);

    if (loading) {
        return <div>Loading...</div>;
    }

    if (!businessDetails) {
        return <div>Business not found.</div>;
    }

    return (
        <Container sx={{
            display: "flex",
            flexDirection: "column"
        }}>
            <img src={`/photos/p` + (businessDetails.review_count%50) + `.jpg`} style={{ width: "50%", objectFit: "cover" }} alt="" />
            <Typography variant="h5" component="div" sx={{ marginTop: "10px", marginBottom: "10px" }}>{businessDetails.name}</Typography>
            <Box sx={{ display: "flex", marginBottom: "10px" }}>
                <Box sx={{ marginRight: "30px", marginBottom: "10px" }}>Stars: {businessDetails.stars}</Box>
                <Box>Review count: {businessDetails.review_count}</Box>
            </Box>
            <Box sx={{ marginBottom: "10px" }}>
                <Box>Location: {businessDetails.address}</Box>
            </Box>
            <Divider />
            <Typography variant="h6" component="div" sx={{ marginTop: "10px", marginBottom: "10px" }}>Daily checkins</Typography>
            <Divider />
            <Plot
                data={
                    data.map((d, i) => {
                        return {
                            x: [d.weekday],
                            y: [d.checkins],
                            type: 'scatter',
                            mode: 'lines+markers',
                            marker: {color: 'red'},
                            name: i
                        }
                    })
                }
                layout={ {width: "100%", height: 300, title: ''} }
                style={{
                    margin: "auto"
                }}
            />
            <Typography variant="h6" component="div" sx={{ marginTop: "10px", marginBottom: "10px" }}>User comments</Typography>
            <Divider />
            <Box sx={{ width: "100%" }}>
                {
                    recentTips.length > 0 ? recentTips.map(tip => {
                        return (
                            <Box sx={{
                                width: "100%",
                                display: "flex",
                                flexDirection: "row",
                                justifyContent: "flex-start",
                                border: "solid 1px black",
                                padding: "10px",
                                marginBottom: "10px"
                            }}>
                                <Box sx={{ width: "200px", overflow: "hidden", whiteSpace: "nowrap", textOverflow: 'ellipsis' }}>
                                    <NavLink to={`/yelp/user/${tip.user_id}`}>{tip.name}</NavLink>
                                    <Typography>Average stars</Typography>
                                    <Box>
                                    <Rating
                                        name="simple-controlled"
                                        disabled={true}
                                        value={tip.average_stars}
                                    />
                                    </Box>
                                </Box>
                                <Box sx={{ display: "flex", flexGrow: 1, paddingLeft: "10px" }}>
                                    {tip.text}
                                </Box>
                            </Box>
                        )
                    }) : (
                        <Typography>None</Typography>
                    )
                }
            </Box>
        </Container>
    );
}

export default BusinessPage;
