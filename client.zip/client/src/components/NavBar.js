import { AppBar, Container, Toolbar, Typography, IconButton, Avatar} from '@mui/material'
import { NavLink } from 'react-router-dom';
// import React, { useState, useEffect} from 'react';
import SearchBar from './SearchBar.js';
const config = require('../config.json');

// function NavImage({ src, alt, href, isMain }) {
//   const imageStyles = {
//     width: isMain ? '100px' : 'auto',
//     height: isMain ? '60px' : 'auto',
//   };

//   return (
//     <IconButton component={NavLink} to={href} style={{ padding: '0' }} disableRipple>
//       <img src={src} alt={alt} style={imageStyles} />
//     </IconButton>
//   );
// }

function NavText({ href, text, isMain }) {
  return (
    <Typography
      variant={isMain ? 'h5' : 'h6'}
      noWrap
      style={{
        marginRight: '30px',
        marginTop: '10px',
        fontSize: '20px',
        fontFamily: 'Arial Black, sans-serif',
        fontWeight: 300,
        color: 'black',
      }}
    >
      <NavLink
        to={href}
        style={{
          color: 'inherit',
          textDecoration: 'none',
        }}
        onMouseEnter={(e) => {
          e.target.style.color = '#CC0000'; // Change the color on hover
        }}
        onMouseLeave={(e) => {
          e.target.style.color = 'inherit'; // Reset the color on mouse leave
        }}
      >
        {text}
      </NavLink>
    </Typography>
  )
}

// Here, we define the NavBar. Note that we heavily leverage MUI components
// to make the component look nice. Feel free to try changing the formatting
// props to how it changes the look of the component.
export default function NavBar() { 

  return (
    <AppBar position='static' style={{ background: 'transparent', boxShadow: 'none' }}>
      <Container maxWidth='xl'>
        <Toolbar disableGutters style={{ justifyContent: 'space-between' }}>
          <div style={{ display: 'flex', alignItems: 'center' }}>
          <NavLink to="/yelp" exact>
            <img
              src='/images/yelp_title.jpg'
              alt='Yelp Logo'
              className="your-image-class"
              style={{ width: '100px', height: '50px' }} 
            />
          </NavLink>
          </div>

          {/* Categories */}
          <NavText href='/yelp/category' text='Categories' />
          <SearchBar />
          {/* Profile Link */}
          <NavLink to='/yelp/user/9VVJ7GUnV4b_pmpAKzIflQ'>
            <Avatar alt="User Avatar" src="/images/user.png" />
          </NavLink>
        </Toolbar>
      </Container>
    </AppBar>
  );
}