import { useEffect, useState } from 'react';
import { NavLink } from 'react-router-dom';

import React from 'react';

import './ScrollingBillboard.css';
const config = require('../config.json');

const ScrollingBillboard = () => {
   
    const [images, setImages] = useState([
      { src: "/posts/new restaurant menus in Mumbai.webp", text: 'Special Healty Menu', searchQuery: '' },
      { src: "/posts/Clean home.webp", text: 'The gift of clean home', searchQuery: '' },
      { src: "/posts/home-checklist-hero.jpeg", text: 'Need some fixing? We can help', searchQuery: '' },
    ]);
    const [currentImageIndex, setCurrentImageIndex] = useState(0);

    useEffect(() => {
      console.log('Fetching data...');
      fetch(`http://${config.server_host}:${config.server_port}/yelp/main_page`)
        .then(res => res.json())
        .then(resJson => {
          console.log('Data received:', resJson);
          const restaurantBusiness = resJson.find(item => item.is_restaurant === 1);
          const homeCategoryBusiness = resJson.find(item => item.categories.toLowerCase().includes("home"));
          const autoCategoryBusiness = resJson.find(item => item.categories.toLowerCase().includes("auto"));
    
          const updatedImages = [...images];

          // Check if the business is found before accessing its properties
          if (restaurantBusiness) {
            updatedImages[0].searchQuery = `${restaurantBusiness.business_id}`;
          }

          if (homeCategoryBusiness) {
            updatedImages[1].searchQuery = `${homeCategoryBusiness.business_id}`;
          }

          if (autoCategoryBusiness) {
            updatedImages[2].searchQuery = `${autoCategoryBusiness.business_id}`;
          }

          setImages(updatedImages);

        })
        .catch(error => console.error('Error:', error));
    }, []);

    const handleDotClick = (index) => {
        setCurrentImageIndex(index);
        resetTimer();
    };

    const handleSearchButtonClick = (searchQuery) => {
        // Implement your search functionality here, e.g., redirect to a search page with the given query
        console.log(`Searching for: ${searchQuery}`);
      };

    // Set up automatic image switching
    useEffect(() => {
        const intervalId = setInterval(() => {
        // Increment currentImageIndex to switch to the next image
        setCurrentImageIndex((prevIndex) => (prevIndex + 1) % images.length);
        }, 5000); // Change the interval time (in milliseconds) as needed

        // Clear the interval when the component is unmounted
        return () => clearInterval(intervalId);
    }, [currentImageIndex]);

    // Function to reset the timer
    const resetTimer = () => {
        clearInterval(); // Clear the existing interval
    };


    return (
        <div className="scrolling-images">
          <div className="images-container" >
        {images.map((image, index) => (
          <div key={index} className={`image ${index === currentImageIndex ? 'active' : 'inactive'}`}>
            {index === currentImageIndex && (
              <>
                <img src={image.src} alt={image.text}/>
                <div className="image-overlay">
                  <p>{image.text}</p>
                  <NavLink to={`/yelp/business/${image.searchQuery}`} activeClassName="active-link" style={{ textDecoration: 'none' }}>
                    <button>Explore</button>
                  </NavLink>
                </div>
              </>
            )}
          </div>
        ))}
            </div>
          <div className="navigation-dots">
            {images.map((_, index) => (
              <span
                key={index}
                className={`dot ${index === currentImageIndex ? 'active' : ''}`}
                onClick={() => handleDotClick(index)}
              />
            ))}
          </div>
        </div>
      );
};

export default ScrollingBillboard;
