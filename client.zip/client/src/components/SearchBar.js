import { Select, MenuItem, InputBase, Button} from '@mui/material'
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import './SearchBar.css';

const SearchBar = () => {
    const navigate = useNavigate();
    const [keyword, setKeyword] = useState('');
    const [state, setState] = useState('');
    const [category, setCategory] = useState('');
    const [city, setCity] = useState('');

    const allCategories = ["Restaurant", "Home Service", "Auto Service", "Others"]
    const allStates = ["AZ","BW","BY","CHE","CMA","EDH","ELN","ESX","FIF","GA","HLD",
    "IL","KY","MLN","NC","NI","NV","NY","NYK","OH","ON","PA","QC","SC","SCB","ST","WI","WLN","XGL"];

    const handleSearch = () => {

        let updatedCategory = category;
        // 处理搜索逻辑，可以根据需要发送请求等
        if (category === "Restaurant") {
            updatedCategory = "restaurant";
          } else if (category === "Home Service") {
            updatedCategory = "home";
          } else if (category === "Auto Service") {
            updatedCategory = "auto";
          } else if (category === "others"){
            updatedCategory = "others";
          } else {
            updatedCategory = "";
          }

        // console.log('Searching for:', { keyword, state, updatedCategory, city });

        const searchLink = `yelp/search?category=${updatedCategory}&keyword=${keyword}&city=${city}&state=${state}`;
// ;
//         console.log(searchLink);

        navigate(searchLink);
        setKeyword('');
        setState('');
        setCategory('');
        setCity('');
    };

    // useEffect(() => {
    //     // 在组件卸载时清空关键字等数据
    //     return () => {
    //       setKeyword('');
    //       setState('');
    //       setCategory('');
    //       setCity('');
    //     };
    //   }, []); 

    return (
    <div className="searchContainer">
        {/* Search Bar */}
        <div className="searchBox">
        <InputBase
        type="text"
        placeholder="Things to do"
        value={keyword}
        onChange={(e) => setKeyword(e.target.value)}
        className="searchInput"
        />
        <InputBase
        type="text"
        placeholder="City"
        value={city}
        onChange={(e) => setCity(e.target.value)}
        className="searchInput"
        />
        <Select
        value={category}
        onChange={(e) => setCategory(e.target.value)}
        displayEmpty
        className="selectInput"
        MenuProps={{ classes: { paper: 'selectMenu' } }}
        IconComponent={() => null} // Hide the dropdown icon
        >
        <MenuItem value="" disabled>
            Category
        </MenuItem>
        {allCategories.map((c, index) => (
    <MenuItem key={index} value={c} className="selectMenuItem">{c}</MenuItem>
))}
        </Select>
        <span className="separator">|</span>
        <Select
        value={state}
        onChange={(e) => setState(e.target.value)}
        displayEmpty
        className="selectInput"
        MenuProps={{ classes: { paper: 'selectMenu' } }}
        IconComponent={() => null} // Hide the dropdown icon
        >
        <MenuItem value="" disabled>
            State
        </MenuItem>
        {allStates.map((state, index) => (
            <MenuItem key={index} value={state} className="selectMenuItem">{state}</MenuItem>
        ))}
        </Select>
        <div>
      {/* 渲染搜索按钮，点击时调用 handleSearch */}
      <Button style={{color: '#CC0000'}} onClick={handleSearch}>Search</Button>
    </div>
        </div>
    </div>
    );    
};

export default SearchBar;