import React, { useEffect, useState } from 'react';
import './ReviewCards.css';
const config = require('../config.json');

const ReviewCards = () => {
    const [business, setBusiness] = useState([]);

    useEffect(() => {
        console.log('Fetching data...');
        fetch(`http://${config.server_host}:${config.server_port}/yelp/recent_tip`)
          .then(res => res.json())
          .then(resJson => {
            console.log('Data received:', resJson);
            setBusiness(resJson);
          })
          .catch(error => console.error('Error:', error));
      }, []);
      

      return (
        <div className="restaurant-review-container">
          <h1>Most popular these days</h1>
          <div className="review-cards-container">
          {business.length > 0 ? (
            // 如果有 business 数据，显示业务信息
            business.map((item, index) => (
              <div key={item.id} className="review-card">
                <img src={`/photos/p${index + 1}.jpg`} className="review-card-image" />
                <div className="review-card-content">
                <a href={`/yelp/business/${item.business_id}`} style={{ textDecoration: 'none', color: 'black' }}>
                  <strong>{item.business_name}</strong>
                </a>
                  <p>"{item.review_text}"</p>
                </div>
              </div>
            ))
          ) : (
            // 如果 business 为空，显示加载指示器
            <div className="loading-indicator">
              <img src="/images/loading.png" alt="Loading Spinner" style={{ width: '20px', height: '20px', marginRight:'20px'}}/>
              Loading...
            </div>
          )}
          </div>
        </div>
      );
      
};

export default ReviewCards;
