import React from 'react';
import './BusinessCard.css'; 

const BusinessCard = ({ business }) => {
    // Define the categories lists
    const homeServiceCategories = [
        "Carpet Cleaning", "Contractors", "Damage Restoration", "Drywall Installation & Repair", "Handyman",
        "Home Services", "Home Cleaning", "Home & Garden", "Landscape Architects", "Landscaping",
        "Movers", "Packing Services", "Pest Control", "Plumbing", "Electricians", "Fences & Gates",
        "Flooring", "Garage Door Services", "Home Window Tinting", "Interior Design", "Lawn Services",
        "Locksmiths", "Moving Services", "Painters", "Pool Cleaners", "Pool & Hot Tub Service",
        "Roofing", "Security Systems", "Septic Services", "Tree Services", "Window Washing",
        "Air Duct Cleaning", "Home Inspectors", "Home Staging", "House Sitters", "HVAC Services",
        "Junk Removal & Hauling", "Masonry/Concrete", "Solar Installation", "Waterproofing",
        "Window Installation"
    ];
    

    const autoServiceCategories = [
        "Automotive", "Tires", "Auto Parts & Supplies", "Auto Repair", "Gas Stations", 
        "Car Dealers", "Used Car Dealers", "Car Wash", "Auto Detailing", "Oil Change Stations",
        "Auto Customization", "Auto Glass Services", "Auto Loan Providers", "Auto Security", 
        "Car Stereo Installation", "Motorcycle Dealers", "Truck Rental", "Car Rental",
        "Towing", "Transmission Repair", "Auto Insurance", "Car Inspectors", "Motorcycle Repair",
        "Parking", "Smog Check Stations", "Tire Shops", "Wheel & Rim Repair"
    ];
    

    const getImageUrl = (business) => {
        if (business.is_restaurant === 1) {
            return '/posts/new restaurant menus in Mumbai.webp';
        } else if (homeServiceCategories.some(cat => business.categories.includes(cat))) {
            return '/posts/Clean home.webp';
        } else if (autoServiceCategories.some(cat => business.categories.includes(cat))) {
            return '/posts/auto-services-article.webp';
        } else {
            return '/posts/others.jpg';
        }
    };

    const imageUrl = getImageUrl(business);

    return (
        <div className="business-card">
            <img src={imageUrl} alt={business.name} className="business-image" />
            <div className="business-info">
                <h3 className="business-name">{business.name}</h3>
                <p className="business-rating">{business.stars} Stars ({business.review_count} Reviews)</p>
            </div>
        </div>
    );
};

export default BusinessCard;
