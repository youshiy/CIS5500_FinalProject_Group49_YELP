const express = require('express');
const cors = require('cors');
const config = require('./config');
const routes = require('./routes');

const app = express();
app.use(cors({
  origin: '*',
}));


// define more routes here
app.get('/yelp/main_page', routes.main_page);
app.get('/yelp/recent_tip', routes.recent_tip);
app.get('/yelp/search', routes.search);
app.get('/yelp/filter_businesses', routes.filter_businesses);
app.get('/yelp/business_details/:businessId', routes.business_details);
app.get('/yelp/top_businesses', routes.top_businesses);
app.get('/yelp/getBusinessPhotos', routes.getBusinessPhotos);
app.get('/yelp/business_checkins/:businessId',routes.business_checkins);
app.get('/yelp/business_tips/:businessId',routes.business_tips);
app.get('/yelp/category_page', routes.category_page);
app.get('/yelp/recommendations', routes.recommendations);
app.get('/yelp/traffic', routes.traffic);
app.get('/yelp/categories', routes.categories);
app.get('/yelp/locations', routes.locations);
app.get('/yelp/user_details/:userId', routes.user_details);
app.get('/yelp/user_tips', routes.user_tips);
app.get('/yelp/user_checkins', routes.user_checkins);
app.get('/yelp/users', routes.users);

app.listen(config.server_port, () => {
  console.log(`Server running at http://${config.server_host}:${config.server_port}/`)
});


module.exports = app;
