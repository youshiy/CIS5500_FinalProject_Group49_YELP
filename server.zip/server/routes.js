const mysql = require('mysql')
const config = require('./config.json')
const {query} = require("express/lib/request");

// Creates MySQL connection using database credential provided in config.json
// Do not edit. If the connection fails, make sure to check that config.json is filled out correctly
const connection = mysql.createConnection({
  host: config.rds_host,
  user: config.rds_user,
  password: config.rds_password,
  port: config.rds_port,
  database: config.rds_db
});

//Connect to MySQL
connection.connect((err) => {
  if (err) {
    console.error('Error connecting to MySQL:', err);
  } else {
    console.log('Connected to MySQL');
  }
});

// Route 1: GET /yelp/main_page
const main_page = function (req, res) {
  connection.query(`
  WITH RankedBusinesses AS (
    SELECT
    business_id,
    name,
    categories,
    is_restaurant,
    stars,
    ROW_NUMBER() OVER (
        PARTITION BY
            CASE
                WHEN is_restaurant = 1 THEN 'restaurant'
                WHEN categories LIKE '%home%' THEN 'home services'
                WHEN categories LIKE '%auto%' THEN 'auto services'
                ELSE 'others'
            END
        ORDER BY stars DESC) AS ranking
    FROM Business
    WHERE stars = 5)
    SELECT business_id, name, categories, is_restaurant, ranking, stars
    FROM RankedBusinesses
    WHERE ranking = 1;
  `, (err, data) => {
    if (err) {
      console.log(err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (data.length === 0) {
      res.status(404).json({ error: 'No data found' });
    } else {
      res.json(data);
    }
  });
}

// Route 2: GET /yelp/recent_tip
const recent_tip = function(req, res) {
  connection.query(`
  SELECT
  DISTINCT T.text AS review_text,
  T.date AS review_date,
  B.name AS business_name,
  B.business_id AS business_id,
  P.photo_id AS photo_id
  FROM
  Tip AS T
  JOIN
  Business AS B ON T.business_id = B.business_id
  JOIN Photo AS P ON B.business_id = P.business_id
  WHERE T.date >= "2017-12-10"
  ORDER BY
  T.date DESC
  LIMIT 20;
  `, (err, data) => {
    if (err || data.length === 0) {
      console.log(err);
      res.json({});
    } else {
      res.json(data);
    }
  });
}

// Route 3: GET /yelp/search?category=restaurant&keywords=asian&city=Toronto&state=ON
const search = function(req, res) {
  const category = req.query.category;
  const keywords = req.query.keywords ?? '';
  const city = req.query.city ?? '';
  const state = req.query.state ?? '';
  if (category === 'restaurant') {
    connection.query(`
  SELECT business_id, name, address, city,
  state, stars, review_count, GROUP_CONCAT(categories) AS categories
  FROM Business
  WHERE is_restaurant = 1 AND
  (name LIKE '%${keywords}%' OR  '${keywords}' = '') AND
  (city = '${city}' OR  '${city}' = '') AND
  (state = '${state}' OR  '${state}' = '')
  GROUP BY business_id
  ORDER BY
  stars DESC, review_count DESC;
  `, (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    });
  } else if (category === "home" || category === "auto" || category === ""){
    connection.query(`
  SELECT business_id, name, address, city,
  state, stars, review_count, GROUP_CONCAT(categories) AS categories
  FROM Business
  WHERE (categories LIKE '%${category}%' OR  '${category}' = '') AND
  (name LIKE '%${keywords}%' OR  '${keywords}' = '') AND
  (city = '${city}' OR  '${city}' = '') AND
  (state = '${state}' OR  '${state}' = '')
  GROUP BY business_id
  ORDER BY
  stars DESC, review_count DESC;
  `, (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    });
  } else {
    connection.query(`
  SELECT business_id, name, address, city,
  state, stars, review_count, GROUP_CONCAT(categories) AS categories
  FROM Business
  WHERE categories NOT LIKE 'home' AND
  categories NOT LIKE 'auto' AND
  is_restaurant = 0 and
  (name LIKE '%${keywords}%' OR  '${keywords}' = '') AND
  (city = '${city}' OR  '${city}' = '') AND
  (state = '${state}' OR  '${state}' = '')
  GROUP BY business_id
  ORDER BY
  stars DESC, review_count DESC;
  `, (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data);
      }
    });
    
  }

}

//Rounte 4: GET/yelp/filter_businesses
//Filter Businesses by Name, City, and Category
const filter_businesses = function(req, res) {
  const { name, city, category } = req.query;

  connection.query(`
    SELECT *
    FROM Business
    WHERE (name LIKE ? OR  ? = '') AND
          (city = ? OR  ? = '') AND
          (categories LIKE ? OR  ? = '') LIMIT 100;
  `, [`%${name}%`, name, city, city, `%${category}%`, category], (err, data) => {
    if (err || data.length === 0) {
      console.log(err);
      res.json({ error: 'No businesses found or error occurred' });
    } else {
      res.json(data);
    }
  });
};


//Route 5: GET/yelp/business_details
//Get Detailed Information for a Specific Business
const business_details = function(req, res) {
  const businessId = req.params.businessId;

  connection.query(`
    SELECT B.business_id, B.name, B.address, B.city, B.state, B.postal_code, B.latitude, B.longitude, B.stars, B.review_count, B.categories,
           COALESCE(C.checkin_total, 0) AS checkin_count,
           COALESCE(T.tip_total, 0) AS tip_count
    FROM Business B
    LEFT JOIN (SELECT business_id, COUNT(*) AS checkin_total FROM Checkin GROUP BY business_id) C ON B.business_id = C.business_id
    LEFT JOIN (SELECT business_id, COUNT(*) AS tip_total FROM Tip GROUP BY business_id) T ON B.business_id = T.business_id
    WHERE B.business_id = '${businessId}';
  `, (err, data) => {
    if (err || data.length === 0) {
      console.log(err);
      res.json({ error: 'Business not found or error occurred' });
    } else {
      res.json(data[0] || {});
    }
  });
};


//Route 6: GET/yelp/top_businesses
const top_businesses = function(req, res) {
  connection.query(`
    SELECT *
    FROM Business
    ORDER BY stars DESC, review_count DESC
    LIMIT 10;
  `, (err, data) => {
    if (err || data.length === 0) {
      console.log(err);
      res.json({ error: 'No businesses found or error occurred' });
    } else {
      res.json(data);
    }
  });
};

//Route 7: GET/yelp/getBusinessPhotos
//Match busniess_id with photo_id
const getBusinessPhotos = function(req, res) {
  const businessId = req.params.businessId;

  connection.query(`
    SELECT B.business_id, P.photo_id
    FROM Business B
    LEFT JOIN BusinessPhotos P ON B.business_id = P.business_id
    WHERE B.business_id = ?;
  `, [businessId], (err, results) => {
    if (err) {
      res.status(500).json({ error: err.message });
    } else {
      res.json(results);
    }
  });
};

// Route 8: GET/yelp/business_checkins
// Get check-ins for a specific business
const business_checkins = function(req, res) {
  const businessId = req.params.businessId;

  connection.query(`
    SELECT * FROM Checkin
    WHERE business_id = ?;
  `, [businessId], (err, results) => {
    if (err) {
      console.log(err);
      res.status(500).json({ error: 'Error occurred while retrieving check-ins' });
    } else {
      res.json(results);
    }
  });
};

// Route 9: GET/yelp/business_tips
// Get tips for a specific business
const business_tips = function(req, res) {
  const businessId = req.params.businessId;

  connection.query(`
    SELECT * FROM Tip T
    LEFT JOIN (SELECT * FROM User)  U ON T.user_id = U.user_id
    WHERE business_id = ?;
  `, [businessId], (err, results) => {
    if (err) {
      console.log(err);
      res.status(500).json({ error: 'Error occurred while retrieving tips' });
    } else {
      res.json(results);
    }
  });
};

// Route 10: GET /yelp/category_page
const category_page = async function(req, res) {
  const sort = (req.query.sort ?? 'review_count').trim();
  const category = (req.query.category ?? '').trim();
  const state = (req.query.state ?? '').trim();
  const city = (req.query.city ?? '').trim();
  const is_open = req.query.is_open ?? '';
  const min_stars = req.query.min_stars ?? 1;
  const min_review_count = req.query.min_review_count ?? 0;

  let query = `
  SELECT business_id, name, stars, review_count, GROUP_CONCAT(categories) AS categories, city, state
  FROM (
    SELECT *
    FROM Business B
    WHERE (B.categories LIKE '%${category}%' OR '${category}' = '') 
      AND (B.city = '${city}' OR '${city}' = '')
      AND (B.state = '${state}' OR '${state}' = '')
      AND B.stars >= ${min_stars}
      AND B.review_count >= ${min_review_count}
      AND (B.is_open = '${is_open}' OR '${is_open}' = '')
    ORDER BY 
      CASE 
        WHEN '${sort}' = 'review_count' THEN B.review_count 
        WHEN '${sort}' = 'stars' THEN B.stars 
        WHEN '${sort}' = 'name' THEN B.name 
      END DESC
    lIMIT 100
    ) AS R
    GROUP BY business_id;`;

  connection.query(query, (err, data) => {
    console.log(data.length)
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    if (data.length === 0) {
      res.status(404).json({ message: 'No data found' });
      return;
    }
    console.log("length",data.length);
    res.json(data);
  });
}

// Route 11: GET /yelp/recommendations
const recommendations = function(req, res) {
  const category = req.query.category ?? [];
  const keywords = req.query.keywords ?? '';
  const city = req.query.city ?? [];
  const state = req.query.state ?? [];
  const order = req.query.order ?? 'Rated';
  const rating = req.query.rating ?? 4;
  const baseCategory = req.query.baseCategory ?? 'Restaurant';
  const review_count = req.query.review_count ?? 0;

  const categories = category.toString().split(',').filter(el => el !== '').map(item => `'${item}'`)
  const cities = city.toString().split(',').filter(el => el !== '').map(item => `'${item}'`);
  const states = state.toString().split(',').filter(el => el !== '').map(item => `'${item}'`);
  const orders = order === 'Rated' ? 'stars' : (order === 'Reviewed' ? 'review_count' : 'name')
  let baseSql = `
  SELECT business_id, name, address, city,
    state, postal_code, latitude, longitude, stars, review_count, GROUP_CONCAT(categories) AS categories
    FROM Business
    WHERE
    stars <= ${rating} AND
    review_count >= ${review_count} AND
    (name LIKE '%${keywords}%' OR '${keywords}' = '')`
  if (categories && categories.length > 0) {
    baseSql = `
      ${baseSql} AND
      (categories IN (${categories}))
    `
  }
  if (cities && cities.length > 0) {
    baseSql = `
      ${baseSql} AND
      (city IN (${cities}))
    `
  }
  if (states && states.length > 0) {
    baseSql = `
      ${baseSql} AND
      (state IN (${states}))
    `
  }
  if (baseCategory === 'Restaurant') {
    baseSql = `
      ${baseSql} AND
      (is_restaurant = 1)
    `
  } else if (["Home Service", "Auto Service"].includes(baseCategory)) {
    baseSql = `
      ${baseSql} AND
      (categories LIKE '%${category}%' OR  '${category}' = '')
    `
  } else {
    baseSql = `
      ${baseSql} AND
      (is_restaurant = 0) AND
      categories NOT LIKE 'home' AND
      categories NOT LIKE 'auto'
    `
  }
  console.log(baseSql)
  connection.query(`
    ${baseSql}
    GROUP BY business_id
    ORDER BY ${orders} DESC
    LIMIT 100;
  `, (err, data) => {
      if (err || data.length === 0) {
        console.log(err);
        res.json({});
      } else {
        res.json(data || []);
        console.log(data.length)
      }
    });
}

// Route 12: GET /yelp/traffic
const traffic = function(req, res) {
  const { category, hour, weekday } = req.query;

  let query = `
    SELECT B.business_id, B.name, SUM(C.checkins) as total_checkins
    FROM Business B
    JOIN Checkin C ON B.business_id = C.business_id
    WHERE 1=1
      ${category ? `AND B.categories LIKE '%${category}%'` : ''}
      ${hour ? `AND HOUR(C.hour) = HOUR('${hour}')` : ''}
      ${weekday ? `AND C.weekday = '${weekday}'` : ''}
    GROUP BY B.business_id, B.name
    ORDER BY total_checkins DESC;`;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    if (data.length === 0) {
      res.status(404).json({ message: 'No data found' });
      return;
    }
    res.json({ data });
  });
};

// Route 13: GET /yelp/categories
const categories = function(req, res) {
  let query = `SELECT DISTINCT categories FROM Business;`;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    if (data.length === 0) {
      res.status(404).json({ message: 'No data found' });
      return;
    }
    res.json({ data });
  });
};

// Route 14: GET /yelp/locations
const locations = function(req, res) {
  let query = `SELECT DISTINCT city, state FROM Business;`;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    if (data.length === 0) {
      res.status(404).json({ message: 'No data found' });
      return;
    }
    res.json({ data });
  });
};

// Route 15: GET /yelp/user
// query.user_id = undefined;
const user_details = function (req, res) {
  const userId = req.params.userId;
  if (!userId) {
    res.status(400).json({ error: 'User ID is required' });
    return;
  }

  const query = `
    SELECT
      user_id,
      name,
      review_count,
      yelping_since,
      useful,
      funny,
      cool,
      friends,
      elite,
      average_stars,
      has_friends
    FROM User
    WHERE user_id = '${userId}';
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (data.length === 0) {
      res.status(404).json({ error: 'User not found' });
    } else {
      res.json(data[0]);
    }
  });
};

// Route 16: GET /yelp/user_tips
const user_tips = function(req, res) {
  const userId = req.query.user_id;
  if (!userId) {
    res.status(400).json({ error: 'User ID is required' });
    return;
  }

  const query = `
    SELECT
      tip_text,
      tip_date,
      business_id,
      likes
    FROM Tip
    WHERE user_id = '${userId}';
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (data.length === 0) {
      res.status(404).json({ error: 'No tips found for this user' });
    } else {
      res.json(data);
    }
  });
};

// Route 17: GET /yelp/user_checkins
const user_checkins = function(req, res) {
  const userId = req.query.user_id;
  if (!userId) {
    res.status(400).json({ error: 'User ID is required' });
    return;
  }

  const query = `
    SELECT
      business_id,
      checkin_date,
      weekday,
      hour
    FROM Checkin
    WHERE user_id = '${userId}';
  `;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
    } else if (data.length === 0) {
      res.status(404).json({ error: 'No checkins found for this user' });
    } else {
      res.json(data);
    }
  });
};

const users = function(req, res) {
  let query = `SELECT * FROM User;`;

  connection.query(query, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Internal Server Error' });
      return;
    }
    if (data.length === 0) {
      res.status(404).json({ message: 'No data found' });
      return;
    }
    res.json(data);
  });
}
module.exports = {
  main_page,
  recent_tip,
  search,
  filter_businesses,
  business_details,
  top_businesses,
  business_checkins,
  business_tips,
  recommendations,
  category_page,
  getBusinessPhotos,
  traffic,
  categories,
  locations,
  user_details,
  user_tips,
  user_checkins,
  users,
}
